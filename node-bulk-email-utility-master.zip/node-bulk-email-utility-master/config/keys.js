module.exports = {
    secretOrKey: "m@g!cM0use@T3LL!uS#398",
    ADMIN_EMAIL: "abhishek_saini@live.com",
    ADMIN_PASSWORD: "nL2G9s$T&@jqZ_GjX3}=yZS2/5-h8+7W"
};